
This package includes

1) DATA_ALL.XLS: raw data
2) DATA_ALL.RAT: RATS data set
3) *.PRG is program file and *.SRC 
   is file of procedures which are called by *.PRG.


Note: To replicate the results, be careful about the
      settings of start date and end date due to missing data, 
      lags selected and first difference.
      The sample period for the calculation of correlation 
      will be different case by case. 
      (i.e. the setting of  START and END for different 
       countries and different variables are different )
      Please refer to the cor1.txt and cor2.txt which may 
      give you the guides about how to set START and END.
